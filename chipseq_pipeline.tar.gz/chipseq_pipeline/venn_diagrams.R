args <- commandArgs(TRUE)

file.1 <- args[1]
file.2 <- args[2]
path <- as.character(args[3])


genes.1 <- as.vector(read.table(file=file.1,header=FALSE)[[1]])
print(length(genes.1))
genes.2 <- as.vector(read.table(file=file.2,header=FALSE)[[1]])
print(length(genes.2))

genes.1.2 <- intersect(genes.1,genes.2)
genes.2.1 <- setdiff(genes.2, genes.1.2)

#### CONSTRUIMOS EL PDF

## print("Número de genes en el background")
## print(length(genes.1))
## print("Número de genes expresados de forma diferencial")
## print(length(genes.2))
## print("Número de genes en la intersección")
## print(length(genes.1.2))

library(VennDiagram)

pdf(paste(path, "venn_diagram.pdf", sep="/"), 7, 7)

label.1 <- "Background"
label.2 <- "Target genes"

grid.newpage()
draw.pairwise.venn(area1 = length(genes.1),
                   area2 = length(genes.2),
                   cross.area = length(genes.1.2),
                   category = c(label.1, label.2), 
                   cat.cex=1.25, cat.pos=c(-30,20), cat.dist=0.04, cex=2,
                   fill=c("red", "blue"),
                   alpha=c(0.4,0.4),
                   lwd=3,fontface="bold",
                   cat.fontface="bold")

dev.off()


write.table(genes.2.1, file= paste(path, "target_genes_not_background.txt", sep= "/"), quote= FALSE)
write.table(genes.1.2, file= paste(path, "intersection_genes.txt", sep="/"), quote=FALSE)

